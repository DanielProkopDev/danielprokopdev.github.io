To run Jar file:
1.open cmd type in: java -version
a)if you see that version is above 21 or 21. you are fine to just click it and try
b)any other results, no java at all, lower version etc:
    1. go to official oracle website and download java at least 21 
           here is the link:    https://www.oracle.com/pl/java/technologies/downloads/#java21
    2. choose version for your platform, Linux/mac/windows, and install it 
    3. for windows users: just download installer(product/file description) its super easy. 